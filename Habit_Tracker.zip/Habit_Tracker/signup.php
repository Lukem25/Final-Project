<?php
include('db_connection.php');
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = 'regular_user';

    // Check if the email already exists
    $stmt = $pdo->prepare('SELECT * FROM Users WHERE email = :email');
    $stmt->execute(['email' => $email]);
    $existingUser = $stmt->fetch();

    if ($existingUser) {
        $error = 'Email already exists. Please use a different email.';
    } else {
        // Insert the new user
        $stmt = $pdo->prepare('INSERT INTO Users (email, password, role) VALUES (:email, :password, :role)');
        if ($stmt->execute(['email' => $email, 'password' => $password, 'role' => $role])) {
            header('Location: signin.php');
            exit;
        } else {
            $error = 'Registration failed. Please try again.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Sign Up</title>
</head>
<body>
<div class="container mt-5">
    <form method="POST" class="p-4 border rounded bg-light">
        <div class="mb-3">
            <label for="email" class="form-label">Email address</label>
            <input type="email" class="form-control" id="email" name="email" required>
        </div>
        <div class="mb-3">
            <label for="password" class="form-label">Password</label>
            <input type="password" class="form-control" id="password" name="password" required>
        </div>
        <button type="submit" class="btn btn-primary w-100">Sign Up</button>
    </form>
    <?php if (isset($error)) echo "<p class='text-danger mt-3'>$error</p>"; ?>
    <a href="public_habits.php" class="btn btn-secondary">View Public Habits</a>
</div>
</body>
</html>
