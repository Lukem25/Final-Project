<?php
session_start();
if (isset($_SESSION['test_key'])) {
    echo $_SESSION['test_key'];
} else {
    echo "Session not set.";
}
?>
