<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: signin.php');
    exit;
}

include('db_connection.php');

// Fetch user's habits
$stmt = $pdo->prepare('SELECT * FROM Habit WHERE user_id = :user_id');
$stmt->execute(['user_id' => $_SESSION['user_id']]);
$habits = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>User Dashboard</title>
</head>
<body>
<div class="container mt-5">
    <h1>Welcome to your Dashboard!</h1>
    <p>Your user ID is: <?php echo htmlspecialchars($_SESSION['user_id']); ?></p>
    <a href="logout.php" class="btn btn-danger mb-3">Logout</a>
    <h2>Your Habits</h2>
    <a href="create_habit.php" class="btn btn-success mb-3">Add New Habit</a>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Name</th>
                <th>Description</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($habits as $habit): ?>
                <tr>
                    <td><?php echo htmlspecialchars($habit['name']); ?></td>
                    <td><?php echo htmlspecialchars($habit['description']); ?></td>
                    <td>
                        <a href="edit_habit.php?id=<?php echo $habit['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                        <a href="delete_habit.php?id=<?php echo $habit['id']; ?>" class="btn btn-danger btn-sm">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
</body>
</html>