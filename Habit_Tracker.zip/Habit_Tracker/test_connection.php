<?php
include('db_connection.php');
echo "Database connection successful!";
?>