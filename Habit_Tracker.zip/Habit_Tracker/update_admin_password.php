<?php
include('db_connection.php');

// Hash the admin password
$hashed_password = password_hash('1234', PASSWORD_DEFAULT);

// Update the admin password in the database
$stmt = $pdo->prepare('UPDATE Users SET password = :password WHERE email = :email');
$stmt->execute([
    'password' => $hashed_password,
    'email' => 'admin@example.com',
]);

echo "Admin password has been hashed and updated.";