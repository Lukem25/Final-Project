<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: signin.php');
    exit;
}

include('db_connection.php');

if (isset($_GET['id'])) {
    $stmt = $pdo->prepare("SELECT * FROM Habit WHERE id = :id AND user_id = :user_id");
    $stmt->execute(['id' => $_GET['id'], 'user_id' => $_SESSION['user_id']]);
    $habit = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$habit) {
        header('Location: dashboard.php');
        exit;
    }
} else {
    header('Location: dashboard.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $description = $_POST['description'];

    $stmt = $pdo->prepare("UPDATE Habit SET name = :name, description = :description WHERE id = :id AND user_id = :user_id");
    $stmt->execute(['name' => $name, 'description' => $description, 'id' => $_GET['id'], 'user_id' => $_SESSION['user_id']]);

    header('Location: dashboard.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Edit Habit</title>
</head>
<body>
<div class="container mt-5">
    <h1>Edit Habit</h1>
    <form method="POST" action="update_habit.php?id=<?php echo $_GET['id']; ?>">
        <div class="mb-3">
            <label for="name" class="form-label">Habit Name</label>
            <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($habit['name']); ?>" required>
        </div>
        <div class="mb-3">
            <label for="description" class="form-label">Description</label>
            <textarea class="form-control" id="description" name="description" rows="3"><?php echo htmlspecialchars($habit['description']); ?></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Save Changes</button>
    </form>
</div>
</body>
</html>
