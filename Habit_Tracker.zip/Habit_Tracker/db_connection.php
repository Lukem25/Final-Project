<?php
$host = 'localhost';
$db = 'habit_tracker';
$user = 'root';
$password = '';
try {
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo 'Database connection error. Please try again later.';
    exit; // Prevent further execution
}
?>
