<?php
// Include the database connection
include('db_connection.php');

// Fetch all habits from the database
$stmt = $pdo->prepare("SELECT h.name, h.description, u.username, h.created_at 
                       FROM Habit h 
                       JOIN Users u ON h.user_id = u.user_id
                       ORDER BY h.created_at DESC");
$stmt->execute();
$habits = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Public Habits</title>
</head>
<body>
<div class="container mt-5">
    <h1 class="mb-4">Public Habits</h1>
    <a href="signin.php" class="btn btn-primary mb-3">Sign In</a>
    <a href="signup.php" class="btn btn-secondary mb-3">Sign Up</a>
    
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Name</th>
                <th>Description</th>
                <th>Created By</th>
                <th>Created At</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($habits)): ?>
                <?php foreach ($habits as $habit): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($habit['name']); ?></td>
                        <td><?php echo htmlspecialchars($habit['description']); ?></td>
                        <td><?php echo htmlspecialchars($habit['username']); ?></td>
                        <td><?php echo htmlspecialchars($habit['created_at']); ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="4" class="text-center">No habits available.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
</body>
</html>