<?php
include('db_connection.php');
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $habit_id = $_POST['habit_id'];
    $completion_date = $_POST['completion_date'];
    $status = $_POST['status'];

    $stmt = $pdo->prepare("
        UPDATE habit_completion 
        SET status = :status 
        WHERE habit_id = :habit_id AND completion_date = :completion_date
    ");
    $stmt->execute([
        'status' => $status,
        'habit_id' => $habit_id,
        'completion_date' => $completion_date,
    ]);
    header('Location: dashboard.php');
    exit;
}
?>
