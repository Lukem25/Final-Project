<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: signin.php');
    exit;
}

include('db_connection.php');

// Check if habit_id is provided
if (isset($_GET['id'])) {
    $habit_id = $_GET['id'];
    
    // Insert a new completion entry for the habit
    $stmt = $pdo->prepare("INSERT INTO Habit_Completion (habit_id) VALUES (:habit_id)");
    $stmt->execute(['habit_id' => $habit_id]);

    // Redirect back to dashboard
    header('Location: dashboard.php');
    exit;
} else {
    echo "Error: No habit ID provided.";
}
?>