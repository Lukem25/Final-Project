<?php
session_start();
include('db_connection.php');

// Check if user is an admin
if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
    header('Location: signin.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id'])) {
    $user_id = $_GET['id'];

    // Delete user
    $stmt = $pdo->prepare('DELETE FROM Users WHERE user_id = :id');
    $stmt->execute(['id' => $user_id]);

    header('Location: admin_users.php');
    exit;
}