<?php
session_start();
include 'db_connection.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: signin.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id'])) {
    $habit_id = $_GET['id'];

    $stmt = $pdo->prepare("SELECT * FROM Habit WHERE id = :id");
    $stmt->execute(['id' => $habit_id]);
    $habit = $stmt->fetch();

    if (!$habit) {
        die("Habit not found.");
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
    $habit_id = $_POST['id'];
    $name = $_POST['name'];
    $description = $_POST['description'];

    $stmt = $pdo->prepare("UPDATE Habit SET name = :name, description = :description WHERE id = :id");
    $stmt->execute([
        'name' => $name,
        'description' => $description,
        'id' => $habit_id,
    ]);

    if ($_SESSION['is_admin']) {
        header('Location: admin_dashboard.php');
    } else {
        header('Location: dashboard.php');
    }
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Habit</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h1 class="mb-4">Edit Habit</h1>
    <form action="edit_habit.php" method="POST" class="bg-light p-4 rounded shadow-sm">
        <input type="hidden" name="id" value="<?php echo htmlspecialchars($habit['id']); ?>">
        <div class="mb-3">
            <label for="name" class="form-label">Name:</label>
            <input type="text" name="name" id="name" class="form-control" value="<?php echo htmlspecialchars($habit['name']); ?>" required>
        </div>
        <div class="mb-3">
            <label for="description" class="form-label">Description:</label>
            <textarea name="description" id="description" class="form-control" rows="3" required><?php echo htmlspecialchars($habit['description']); ?></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Save</button>
        <a href="<?php echo $_SESSION['is_admin'] ? 'admin_dashboard.php' : 'dashboard.php'; ?>" class="btn btn-secondary">Cancel</a>
    </form>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>