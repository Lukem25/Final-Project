<?php
session_start();
if (isset($_SESSION['user_id'])) {
    echo "Session is active. User ID: " . $_SESSION['user_id'];
} else {
    echo "No active session.";
}
?>
