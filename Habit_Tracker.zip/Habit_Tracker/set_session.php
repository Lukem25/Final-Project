<?php
session_start();
$_SESSION['test_key'] = 'Session is working!';
echo "Session set.";
?>
