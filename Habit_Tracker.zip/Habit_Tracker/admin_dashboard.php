<?php
session_start();
include('db_connection.php');

// Check if user is an admin
if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
    header('Location: signin.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h1>Admin Dashboard</h1>
    <a href="logout.php" class="btn btn-danger mb-3">Logout</a>
    <a href="admin_users.php" class="btn btn-primary mb-3">Manage Users</a>
    <h2>All Habits</h2>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Description</th>
                <th>User ID</th>
                <th>Created At</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $stmt = $pdo->prepare('SELECT * FROM Habit');
            $stmt->execute();
            $habits = $stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach ($habits as $habit): ?>
                <tr>
                    <td><?php echo htmlspecialchars($habit['id']); ?></td>
                    <td><?php echo htmlspecialchars($habit['name']); ?></td>
                    <td><?php echo htmlspecialchars($habit['description']); ?></td>
                    <td><?php echo htmlspecialchars($habit['user_id']); ?></td>
                    <td><?php echo htmlspecialchars($habit['created_at']); ?></td>
                    <td>
                        <a href="edit_habit.php?id=<?php echo $habit['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                        <a href="delete_habit.php?id=<?php echo $habit['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this habit?');">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
</body>
</html>